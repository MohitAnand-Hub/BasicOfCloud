# Explore more

In case you'd like to expand your knowledge beyond cloud computing, here are some additional resources I think are fantastic.

| Title                     | Resource                                                                                                                                               |
 | :------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------ |
 | [Web development for beginners](https://docs.microsoft.com/en-us/learn/paths/web-development-101/)| A 2 hour into to web development                                              |
 | [Practical dotnet](https://practicaldotnet.io/)             | I used this to sharpen my Blazor skills. |
 
