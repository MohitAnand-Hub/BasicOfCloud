---
name: Submit project
about: Submit you project or share your project idea
title: PROJ
labels: ''
assignees: ''

---

---
name: "\U0001F680 Project"
about: Your project/project idea.

---

<!--
Thank you for suggesting an idea to make learntocloud.guide better.

Please fill in as much of the template below as you're able.
-->

**What is your project related to? Please describe.**
Please describe the problem you are trying to solve.

**Which phase your project falls under?**
- [ ] Phase 1
- [ ] Phase 2
- [ ] Phase 3
- [ ] Phase 4

**Tech stack/Technologies being used**
Please describe different services/technologies that will be used.
