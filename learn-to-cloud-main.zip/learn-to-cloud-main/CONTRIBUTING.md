## How to contribute to Learn to Cloud Guide

The Learn to Cloud guide is still in a baby phase and only static content. We have plans to grow! For now, we are looking for Project contributions. In each phase there is a Community Projects
section, please feel free to open an issue with your project idea.

Thanks! :heart: :heart: :heart:

GPS and Rishab
